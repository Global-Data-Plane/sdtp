#!/usr/bin/env python

"""Tests for `sdtp` package."""

# import pytest



