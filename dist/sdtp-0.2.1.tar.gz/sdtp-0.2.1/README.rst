==========
Simple Data Transfer Protocol
==========



A Python implementation of the Simple Data Transfer Protocol data structures,  functions, and server. This is a reference server  for the Simple Data Transfer Protocol.  It demonstrates the Simple Data Transfer Protocol Server API.  It also functions as an open framework, so new Tables can be attached to the Simple Data Transfer Protocol server by providing a Class with a `get_rows()` method and a `columns` property.


* Free software: BSD 3-clause license
* Documentation: https://sdtp.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
